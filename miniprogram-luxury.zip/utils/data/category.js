export default [
  {
    id: 1,
    name: '腕表',
    pic: 'https://www.bositu666.com/minimallimg/category/9ce28f05fa374c509236e92c1327977a.png'
  },
  {
    id: 2,
    name: '箱包',
    pic: 'https://www.bositu666.com/minimallimg/category/aeb0b0b4eac34643b5c8a58428744f93.png'
  },
  {
    id: 3,
    name: '首饰',
    pic: 'https://www.bositu666.com/minimallimg/category/1475412eca7b4b62b9fb8cfeaaf4efb9.png'
  },
  {
    id: 4,
    name: '其他',
    pic: 'https://www.bositu666.com/minimallimg/category/6ba208dde7444bbd9350cffbf49c0702.png'
  }
]
