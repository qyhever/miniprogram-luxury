<template>
  <view>
    <scroll-view class="aside" scroll-y>
      <view
        v-for="(item, index) in categoryList"
        :key="index"
        class="category-item"
        :class="{active: activeCategoryId === item.id}"
        @click="onCategoryItemClick(item)"
      >
        {{ item.name }}
      </view>
    </scroll-view>
  </view>
</template>

<script>
import categoryList from '@/utils/data/category'
export default {
  data () {
    return {
      categoryList,
      activeCategoryId: 1
    }
  },
  methods: {
    onCategoryItemClick ({ id }) {
      if (this.activeCategoryId !== id) {
        this.activeCategoryId = id
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.aside {
  height: 100vh;
}
.category-item {
  position: relative;
  height: 50px;
  line-height: 50px;
  text-align: center;
  background-color: $color-bg-light;
  &:before {
    content: "";
    position: absolute;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    width: 5px;
    height: 20px;
    border-radius: 3px;
    background-color: $color-primary;
    opacity: 0;
    transition: opacity .3s ease-in-out;
  }
  &.active {
    background-color: $color-bg;
    color: $color-primary;
    &:before {
      opacity: 1;
    }
  }
}
</style>
