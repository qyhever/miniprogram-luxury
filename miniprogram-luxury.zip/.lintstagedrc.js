module.exports = {
  '*.{js,vue}': ['eslint --fix']
}
